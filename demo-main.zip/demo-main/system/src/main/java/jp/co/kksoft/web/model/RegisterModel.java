package jp.co.kksoft.web.model;

import lombok.Data;

@Data
public class RegisterModel {

	private String username;
	private String pwd;
	private String address;
	private String email;
}
