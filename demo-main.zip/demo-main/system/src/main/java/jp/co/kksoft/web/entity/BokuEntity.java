package jp.co.kksoft.web.entity;

import lombok.Data;

@Data
public class BokuEntity {

	private String username;
	private String pwd;
	private String address;
	private String email;
}
